import './App.css';
import Projects from './Projects';

function App() {
  return (
    <div className="App">
      <Projects username={'Drew'} />
    </div>
  );
}

export default App;
